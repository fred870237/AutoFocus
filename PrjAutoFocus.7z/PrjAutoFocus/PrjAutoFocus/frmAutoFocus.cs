﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrjAutoFocus
{
    public partial class frmAutoFocus : Form
    {
        // Log
        private CommonBase.Logger.InfoManager g_InfoManager;




        public frmAutoFocus()
        {
            InitializeComponent();
        }

        private void frmAutoFocus_Load(object sender, EventArgs e)
        {

        }

        private void frmAutoFocus_FormClosed(object sender, FormClosedEventArgs e)
        {
            // log
            try
            {
                if (this.g_InfoManager != null) this.g_InfoManager.Dispose();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        private void frmAutoFocus_FormClosing(object sender, FormClosingEventArgs e)
        {

        }
    }
}
