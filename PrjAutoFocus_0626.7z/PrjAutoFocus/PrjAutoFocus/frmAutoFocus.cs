﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PrjAutoFocus.Class;

using LiveCharts;
using LiveCharts.Wpf;

namespace PrjAutoFocus
{
    public partial class frmAutoFocus : Form
    {
        // Config
        private ClsBootConfig g_ClsBootConfig = null;
        private ClsSerialPortConfig g_ClsSerialPortConfig = null;
        private ClsDaqModuleConfig g_ClsDaqModuleConfig = null;

        // Control
        private ClsSerialPortControl g_ClsSerialPortControl = null;
        private ClsDaqModuleControl g_ClsDaqModuleControl = null;

        // Log
        private CommonBase.Logger.InfoManager g_InfoManager;

        //
        private System.Diagnostics.Stopwatch g_Stopwatch;
        private int g_SendCnt = 0;

        public frmAutoFocus()
        {
            InitializeComponent();
        }

        private void funcCheckConfigExist()
        {
            try
            {
                // boot config
                this.g_ClsBootConfig = new ClsBootConfig();
                if (File.Exists(Common.CONFIG_FOLDER + Common.BOOT_CONFIG_NAME))
                {
                    try
                    {
                        this.g_ClsBootConfig.ReadWithoutCrypto(Common.CONFIG_FOLDER + Common.BOOT_CONFIG_NAME);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString());
                        this.g_ClsBootConfig.ReadWithoutCrypto(Common.DEFAULT_CONFIG_FOLDER + Common.BOOT_CONFIG_NAME);
                    }
                    this.g_ClsBootConfig.WriteWithoutCrypto(Common.CONFIG_FOLDER + Common.BOOT_CONFIG_NAME, true);
                }
                else
                {
                    try
                    {
                        string temp_BootConfigFolder = Path.GetDirectoryName(Common.CONFIG_FOLDER + Common.BOOT_CONFIG_NAME);
                        if (!Directory.Exists(temp_BootConfigFolder))
                        {
                            Directory.CreateDirectory(temp_BootConfigFolder);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString(), "Create BootConfig folder fail");
                    }

                    this.g_ClsBootConfig.WriteWithoutCrypto(Common.CONFIG_FOLDER + Common.BOOT_CONFIG_NAME, true);
                }

                //
                if (!System.IO.File.Exists(Common.CONFIG_FOLDER + Common.SERIAL_PORT_CONFIG_NAME)) {
                    this.g_ClsSerialPortConfig = new ClsSerialPortConfig();
                    this.g_ClsSerialPortConfig.WriteWithoutCrypto(Common.CONFIG_FOLDER + Common.SERIAL_PORT_CONFIG_NAME, true);
                }

                //
                if (!System.IO.File.Exists(Common.CONFIG_FOLDER + Common.DAQ_MODULE_CONFIG_NAME ))
                {
                    this.g_ClsDaqModuleConfig = new ClsDaqModuleConfig();
                    this.g_ClsDaqModuleConfig.WriteWithoutCrypto(Common.CONFIG_FOLDER + Common.DAQ_MODULE_CONFIG_NAME, true);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void funcLoadRecipe()
        {
            try
            {
                this.txtFactorA.Text = this.g_ClsBootConfig.factorA.ToString("F3");
                this.txtFactorB.Text = this.g_ClsBootConfig.factorB.ToString("F3");

                //
                this.nudDefaultDistance.Value = new decimal(this.g_ClsBootConfig.defaultDistance);

                this.dataGridView1.Rows.Clear();
                string[] sTemp = new string[this.dataGridView1.ColumnCount];
                for (int i = 0; i < this.g_ClsBootConfig.l_st_Calibration_Data_.Count; i++)
                {
                    int j = 0;
                    sTemp[j] = this.g_ClsBootConfig.l_st_Calibration_Data_[i].voltage.ToString(); j++;
                    sTemp[j] = this.g_ClsBootConfig.l_st_Calibration_Data_[i].distance.ToString(); j++;

                    double tempShift = this.g_ClsBootConfig.l_st_Calibration_Data_[i].distance -
                        this.g_ClsBootConfig.defaultDistance;
                    sTemp[j] = tempShift.ToString("F4"); j++;

                    this.dataGridView1.Rows.Add(sTemp);
                    this.dataGridView1.Rows[i].HeaderCell.Value = i.ToString();
                }

            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }

        }

        private void funcSaveRecipe()
        {
            try
            {
                this.g_ClsBootConfig.factorA = Convert.ToDouble(this.txtFactorA.Text);
                this.g_ClsBootConfig.factorB = Convert.ToDouble(this.txtFactorB.Text);

                //
                this.g_ClsBootConfig.defaultDistance = (double)this.nudDefaultDistance.Value;

                //
                this.g_ClsBootConfig.l_st_Calibration_Data_.Clear();
                for (int i = 0; i < this.dataGridView1.RowCount - 1; i++)
                {
                    _st_Calibration_Data_ temp_st_Calibration_Data_ = new _st_Calibration_Data_
                    {
                        voltage = double.Parse(this.dataGridView1.Rows[i].Cells[0].Value.ToString()),
                        distance = double.Parse(this.dataGridView1.Rows[i].Cells[1].Value.ToString())
                    };
                    this.g_ClsBootConfig.l_st_Calibration_Data_.Add(temp_st_Calibration_Data_);
                }
                this.g_ClsBootConfig.WriteWithoutCrypto(Common.CONFIG_FOLDER + Common.BOOT_CONFIG_NAME, true);
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }

        }

        private bool funcLinearRegression(double[,] point, ref double o_factorA, ref double o_factorB)
        {
            double AverageX = 0, AverageY = 0;
            double Numerator = 0;
            double Denominator = 0;
            double RCB;
            double RCA;
            double Residual_SS = 0;
            double Regression_SS = 0;

            if (point.GetLength(0) < 2)
            {
                Console.WriteLine("點的數量小於2，無法進行線性回歸");
                return false;
            }
            for (int i = 0; i < point.GetLength(0); i++)
            {
                AverageX += point[i, 0];
                AverageY += point[i, 1];
            }
            AverageX /= point.GetLength(0);
            AverageY /= point.GetLength(0);
            Console.WriteLine("平均X: {0}\n平均Y: {1}", AverageX, AverageY);
            for (int i = 0; i < point.GetLength(0); i++)
            {
                Numerator += (point[i, 0] - AverageX) * (point[i, 1] - AverageY);
                Denominator += (point[i, 0] - AverageX) * (point[i, 0] - AverageX);
            }
            RCB = Numerator / Denominator;
            RCA = AverageY - RCB * AverageX;

            Console.WriteLine("回歸係數A： " + RCA.ToString("0.0000"));
            Console.WriteLine("回歸係數B： " + RCB.ToString("0.0000"));
            Console.WriteLine(string.Format("方程為： y = {0} + {1} * x",
                RCA.ToString("0.0000"), RCB.ToString("0.0000")));
            for (int i = 0; i < point.GetLength(0); i++)
            {
                Residual_SS += (point[i, 1] - RCA - RCB * point[i, 0]) * (point[i, 1] - RCA - RCB * point[i, 0]);
                Regression_SS += (RCA + RCB * point[i, 0] - AverageY) * (RCA + RCB * point[i, 0] - AverageY);
            }
            Console.WriteLine("剩餘平方和： " + Residual_SS.ToString("0.0000"));
            Console.WriteLine("回歸平方和： " + Regression_SS.ToString("0.0000"));

            o_factorA = RCA;
            o_factorB = RCB;

            return true;
        }

        private void frmAutoFocus_Load(object sender, EventArgs e)
        {
            this.Text = Common.SOFTWARE_APP_VERSION;


            try {
                this.funcCheckConfigExist();
            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
            }

            // log 
            // controller
            try
            {
                this.g_InfoManager = new CommonBase.Logger.InfoManager(
                    this.g_ClsBootConfig.rootPath + "\\Log\\systemlog",
                    this.g_ClsBootConfig.rootPath + "\\Log\\networklog",
                    this.g_ClsBootConfig.rootPath + "\\Log\\warninglog",
                    this.g_ClsBootConfig.rootPath + "\\Log\\errorlog",
                    this.g_ClsBootConfig.rootPath + "\\Log\\debuglog");

                this.g_InfoManager.SetGeneralTextBox(ref this.rtfLogSystem);
                this.g_InfoManager.SetErrorTextBox(ref this.rtfLogError);
            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
            }
          

            //
            try
            {
                this.funcLoadRecipe();

                //
                double[] data1 = new double[this.g_ClsBootConfig.l_st_Calibration_Data_.Count];

                chart1.Series[0].Points.Clear();
                for (int i = 0; i < this.g_ClsBootConfig.l_st_Calibration_Data_.Count; i++)
                {
                    double xData = this.g_ClsBootConfig.l_st_Calibration_Data_[i].distance -
                        this.g_ClsBootConfig.defaultDistance;

                    double yData = this.g_ClsBootConfig.l_st_Calibration_Data_[i].voltage;

                    chart1.Series[0].Points.AddXY(xData, yData);
                    if (i == 0 ||
                        i == this.g_ClsBootConfig.l_st_Calibration_Data_.Count - 1 ||
                        i % 2 == 0)
                    {
                        chart1.Series[0].Points[i].Label = xData.ToString("F4");
                    }
                }
                // 建立好資料
                // 匯入Chart1
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }

            //
            this.btnConnect.Enabled = true;
            this.btnDisConnect.Enabled = false;
            this.gbxStepCompensated.Enabled = false;
            this.gbxClickCompensated.Enabled = false;
            this.gbxAutoCompensated.Enabled = false;


            //
            this.g_Stopwatch = new System.Diagnostics.Stopwatch();

        }

        private void frmAutoFocus_FormClosed(object sender, FormClosedEventArgs e)
        {
            // log
            try
            {
                if (this.g_InfoManager != null) this.g_InfoManager.Dispose();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        private void frmAutoFocus_FormClosing(object sender, FormClosingEventArgs e)
        {

        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            int ret = 0;

            // connect gap sensor
            try
            {

                //
                if (this.g_ClsSerialPortConfig != null) { this.g_ClsSerialPortConfig = null; }
                this.g_ClsSerialPortConfig = new ClsSerialPortConfig();

                if (System.IO.File.Exists(Common.CONFIG_FOLDER + Common.SERIAL_PORT_CONFIG_NAME))
                {
                    this.g_ClsSerialPortConfig.ReadWithoutCrypto(Common.CONFIG_FOLDER + Common.SERIAL_PORT_CONFIG_NAME);
                }
                this.g_ClsSerialPortControl = new ClsSerialPortControl(this.g_ClsSerialPortConfig, this.g_InfoManager);
                this.g_ClsSerialPortControl.m_funcUpdateDistanceCallBack += new funcUpdateDistanceCallBack(this.funcUpdateDistance);
                this.g_ClsSerialPortControl.m_funcClickCompensatedCallBack += new funcClickCompensatedCallBack(this.funcClickCompensated);
                this.g_ClsSerialPortControl.m_funcAutoCompensatedCallBack += new funcAutoCompensatedCallBack(this.funcAutoCompensated);

                if (!this.g_ClsSerialPortControl.Open())
                {
                    ret++;
                }
                else
                {
                    this.g_InfoManager.General("Open gap sensor successfully");
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error("Open gap sensor error : " + ex.Message);
            }

            // connect adlink usb-1902
            try
            {
                //
                if (this.g_ClsDaqModuleConfig != null) { this.g_ClsDaqModuleConfig = null; }
                this.g_ClsDaqModuleConfig = new ClsDaqModuleConfig();

                if (System.IO.File.Exists(Common.CONFIG_FOLDER + Common.DAQ_MODULE_CONFIG_NAME))
                {
                    this.g_ClsDaqModuleConfig.ReadWithoutCrypto(Common.CONFIG_FOLDER + Common.DAQ_MODULE_CONFIG_NAME);
                }
                this.g_ClsDaqModuleControl = new ClsDaqModuleControl(this.g_ClsDaqModuleConfig, this.g_InfoManager);

                if (!this.g_ClsDaqModuleControl.Open())
                {
                    ret++;
                }
                else
                {
                    this.g_InfoManager.General("Open adlink DAO successfully");
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error("Open adlink DAO error : " + ex.Message);
            }

            if (ret > 0)
            {
                this.g_InfoManager.Error("Connect device fail, please check the device setting!");
            }
            else
            {
                this.btnConnect.Enabled = false;
                this.btnDisConnect.Enabled = true;
                this.gbxStepCompensated.Enabled = true;
                this.gbxClickCompensated.Enabled = true;
                this.gbxAutoCompensated.Enabled = true;
            }

        }

        private void btnSendVoltage_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsDaqModuleControl != null)
                {
                    double tmpVoltage = Convert.ToDouble(this.txtVoltage.Text);
                    this.g_ClsDaqModuleControl.SendVoltage(tmpVoltage);

                    this.g_InfoManager.HighLight("Send : " + tmpVoltage + " (V)");
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }
        }

        private void btnDisConnect_Click(object sender, EventArgs e)
        {
            // disconnect gap sensor
            try
            {
                if (this.g_ClsSerialPortControl != null)
                {
                    this.g_ClsSerialPortControl.Close();
                    this.g_InfoManager.General("Close gap sensor successfully");
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error("Close gap sensor error : " + ex.Message);
            }

            // disconnect adlink usb-1902
            try
            {
                if (this.g_ClsDaqModuleControl != null)
                {
                    this.g_ClsDaqModuleControl.Close();
                    this.g_InfoManager.General("Close  adlink DAO successfully");
                }

            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error("Close adlink DAO error : " + ex.Message);
            }

            this.btnConnect.Enabled = true;
            this.btnDisConnect.Enabled = false;
            this.gbxStepCompensated.Enabled = false;
            this.gbxClickCompensated.Enabled = false;
            this.gbxAutoCompensated.Enabled = false;

        }

        private void funcUpdateDistance(double o_Distance)
        {
            if (this.txtMeasureDistance.InvokeRequired)
            {
                var d = new funcUpdateDistanceCallBack(funcUpdateDistance);
                this.txtMeasureDistance.Invoke(d, new object[] { o_Distance });
            }
            else
            {
                this.txtMeasureDistance.Text = o_Distance.ToString("F4");
            }
        }

        private void btnGetDistance_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsSerialPortControl != null)
                {
                    this.g_ClsSerialPortControl.Send("M\r");
                }                
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }
        }

        private double funcCalculateVoltage()
        {
            double tempVoltage = 0;

            try
            {
                double tempFactorA = Convert.ToDouble(this.txtFactorA.Text);
                double tempFactorB = Convert.ToDouble(this.txtFactorB.Text);
                double tempshift = Convert.ToDouble(this.txtMeasureDistance.Text);

                // voltage = tempFactorB * Measure Distance (shift) + tempFactorA;
                tempVoltage = tempFactorB * tempshift + tempFactorA;

                //this.g_InfoManager.General("[Calculate Voltage] : " + tempVoltage);

                if (tempVoltage > this.g_ClsBootConfig.maxVoltage)
                {
                    string tempStr = string.Format("Calculate voltage {0} is great than {1}, set to {2}",
                        tempVoltage, this.g_ClsBootConfig.maxVoltage, this.g_ClsBootConfig.maxVoltage);

                    //this.g_InfoManager.HighLight(tempStr);

                    tempVoltage = this.g_ClsBootConfig.maxVoltage;
                }
                else if (tempVoltage < this.g_ClsBootConfig.minVoltage)
                {
                    string tempStr = string.Format("Calculate voltage {0} is less than {1}, set to {2}",
                        tempVoltage, this.g_ClsBootConfig.minVoltage, this.g_ClsBootConfig.minVoltage);

                    //this.g_InfoManager.HighLight(tempStr);

                    tempVoltage = this.g_ClsBootConfig.minVoltage;
                }

            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }

            return tempVoltage;
        }

        private void btnCalculateVoltage_Click(object sender, EventArgs e)
        {
            this.txtVoltage.Text = this.funcCalculateVoltage().ToString("F3");       
        }

        private void btnSaveRecipe_Click(object sender, EventArgs e)
        {
            this.funcSaveRecipe();
        }

        private void btnLoadConfig_Click(object sender, EventArgs e)
        {
            this.funcLoadRecipe();

            //
            double[] data1 = new double[this.g_ClsBootConfig.l_st_Calibration_Data_.Count];

            chart1.Series[0].Points.Clear();
            for (int i = 0; i < this.g_ClsBootConfig.l_st_Calibration_Data_.Count; i++)
            {
                double xData = this.g_ClsBootConfig.l_st_Calibration_Data_[i].distance - 
                    this.g_ClsBootConfig.defaultDistance;

                double yData = this.g_ClsBootConfig.l_st_Calibration_Data_[i].voltage;
                   
                chart1.Series[0].Points.AddXY(xData, yData);
                if (i == 0 ||
                    i == this.g_ClsBootConfig.l_st_Calibration_Data_.Count - 1 ||
                    i % 2 == 0) {
                    chart1.Series[0].Points[i].Label = xData.ToString("F4");
                }
            }
            // 建立好資料
            // 匯入Chart1

        }

        private void btnCalibate_Click(object sender, EventArgs e)
        {
            try
            {
                int tempGroupCnt = this.dataGridView1.RowCount-1;

                double[, ] tempPoint = new double[tempGroupCnt, 2];
                for (int i = 0; i < tempGroupCnt; i++)
                {
                    // voltage
                    tempPoint[i, 1] = double.Parse(this.dataGridView1.Rows[i].Cells[0].Value.ToString());

                    // shift
                    tempPoint[i, 0] = double.Parse(this.dataGridView1.Rows[i].Cells[2].Value.ToString());
                }

                double tempFactorA = 0;
                double tempFactorB = 0;

                if (!this.funcLinearRegression(tempPoint, ref tempFactorA, ref tempFactorB))
                {
                    this.g_InfoManager.Error("Calibration fail");
                }
                this.txtFactorA.Text = tempFactorA.ToString("F3");
                this.txtFactorB.Text = tempFactorB.ToString("F3");
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }

        }

        private void frmAutoFocus_Resize(object sender, EventArgs e)
        {
            try
            {

                //
                this.btnCalibate.Location = new System.Drawing.Point(
                    this.btnCalibate.Location.X,
                    this.chart1.Location.Y + this.chart1.Height + 6);

                //
                this.lblFormula.Location = new System.Drawing.Point(
                    this.lblFormula.Location.X,
                    this.btnCalibate.Location.Y + this.btnCalibate.Height + 6);

                //
                this.lblTitleY.Location = new System.Drawing.Point(
                    this.lblTitleY.Location.X,
                    this.lblFormula.Location.Y + this.lblFormula.Height + 9);

                this.txtFactorB.Location = new System.Drawing.Point(
                   this.txtFactorB.Location.X,
                   this.lblFormula.Location.Y + this.lblFormula.Height + 6);

                this.lblTitleX.Location = new System.Drawing.Point(
                    this.lblTitleX.Location.X,
                    this.lblFormula.Location.Y + this.lblFormula.Height + 9);

                this.txtFactorA.Location = new System.Drawing.Point(
                   this.txtFactorA.Location.X,
                    this.lblFormula.Location.Y + this.lblFormula.Height + 6);
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }

        }

        private void funcClickCompensated(double o_Distance)
        {
            if (this.txtMeasureDistance.InvokeRequired)
            {
                var d = new funcClickCompensatedCallBack(funcClickCompensated);
                this.txtMeasureDistance.Invoke(d, new object[] { o_Distance });
            }
            else
            {
                // get distance
                this.txtMeasureDistance.Text = o_Distance.ToString("F4");

                // calculate voltage
                double tempVoltage = 0;
                tempVoltage = this.funcCalculateVoltage();
                this.txtVoltage.Text = tempVoltage.ToString("F3");

                // send voltage
                if (this.g_ClsDaqModuleControl != null)
                {
                    this.g_ClsDaqModuleControl.SendVoltage(tempVoltage);
                }
            }
        }

        private void funcAutoCompensated(double o_Distance)
        {

            if (this.txtMeasureDistance.InvokeRequired)
            {
                var d = new funcAutoCompensatedCallBack(funcAutoCompensated);
                this.txtMeasureDistance.Invoke(d, new object[] { o_Distance });
            }
            else
            {
                // get distance
                this.txtMeasureDistance.Text = o_Distance.ToString("F4");

                // calculate voltage
                double tempVoltage = 0;
                tempVoltage = this.funcCalculateVoltage();
                this.txtVoltage.Text = tempVoltage.ToString("F3");

                // send voltage
                if (this.g_ClsDaqModuleControl != null)
                {                 
                    this.g_ClsDaqModuleControl.SendVoltage(tempVoltage);
                    this.g_SendCnt++;
                }

                if (this.g_Stopwatch.ElapsedMilliseconds > 1000)
                {
                    this.g_InfoManager.HighLight("Send Cnt : " + this.g_SendCnt);
                    this.g_SendCnt = 0;
                    this.g_Stopwatch.Restart();
                }

                // send get distance again
                if (this.g_ClsSerialPortControl.isAutoCompensated)
                {
                    //
                    this.g_ClsSerialPortControl.Send("M\r");
                }

            }         
        }

        private void BtnAutoCompensated_Click(object sender, EventArgs e)
        {

            try
            {
                if (this.btnAutoCompensated.Text == "Start")
                {
                    if (this.g_ClsSerialPortControl != null)
                    {
                        this.g_ClsSerialPortControl.isAutoCompensated = true;
                        this.g_ClsSerialPortControl.Send("M\r");
                        this.g_Stopwatch.Restart();

                        this.btnAutoCompensated.Text = "Stop";
                        this.btnAutoCompensated.BackColor = Color.Red;
                    }
                }
                else
                {
                    this.g_ClsSerialPortControl.isAutoCompensated = false;

                    this.btnAutoCompensated.Text = "Start";
                    this.btnAutoCompensated.BackColor = Color.Green;
                }


            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }
        }

        private void TxtVoltage_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {

                this.btnSendVoltage.Focus();

                this.btnSendVoltage_Click(sender, e);

                this.txtVoltage.Focus();

            }
        }

        private void BtnClickCompensated_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsSerialPortControl != null)
                {
                    this.g_ClsSerialPortControl.isClickCompensated = true;
                    this.g_ClsSerialPortControl.Send("M\r");
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }

        }
    }
}
