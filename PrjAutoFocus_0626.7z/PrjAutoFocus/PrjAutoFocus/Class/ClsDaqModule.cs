﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrjAutoFocus.Class
{
    public partial class ClsDaqModuleConfig : CommonBase.Config.BaseConfig<ClsDaqModuleConfig>
    {
        private string classVersion = "BestintechConfig_201911281136";

        public string cardType;
        public ushort cardID;

        public ClsDaqModuleConfig()
        {
            this.cardType = "USB1902";
            this.cardID = 0;
        }

        protected override bool CheckValue(ClsDaqModuleConfig tmpConfig)
        {
            // ...
            this.cardType = tmpConfig.cardType;
            this.cardID = tmpConfig.cardID;

            //	Read UPDATE
            this.Update = tmpConfig.Update;

            //	Read VERSION
            this.Version = this.classVersion;

            if (this.Version != tmpConfig.Version)
                return false;
            else
                return true;
        }
    }


    class ClsDaqModuleControl
    {
        private CommonBase.Logger.InfoManager m_InfoManager;

        private ClsDaqModuleConfig m_ClsDaqModuleConfig;

        private ushort wCardType;
        private ushort wCardID;
        private ushort Module_Num;

        public ClsDaqModuleControl(
            ClsDaqModuleConfig o_ClsDaqModuleConfig,
            CommonBase.Logger.InfoManager o_InfoManager)
        {
            //
            this.m_ClsDaqModuleConfig = o_ClsDaqModuleConfig;

            //
            this.m_InfoManager = o_InfoManager;

            //
            if (this.m_ClsDaqModuleConfig.cardType == "USB1902")
            {
                this.wCardType = USBDASK.USB_1902;
            }
            this.wCardID = this.m_ClsDaqModuleConfig.cardID;

            this.Module_Num = USBDASK.INVALID_CARD_ID;
        }

        public bool Open()
        {      
            bool ret = true;
            short iTemp;

            try
            {
                iTemp = USBDASK.UD_Register_Card(this.wCardType, this.wCardID);
                if (iTemp < 0)
                {
                    this.m_InfoManager.Error("UD_Register_Card() Fail, Code:" + iTemp.ToString());
                    ret = false;
                }
                Module_Num = (ushort)iTemp;

                // Configure AI Channel
                short err = USBDASK.UD_AI_1902_Config(Module_Num, USBDASK.P1902_AI_PseudoDifferential, 0, 0, 0, 0);
                if (err != USBDASK.NoError)
                {
                    this.m_InfoManager.Error("UD_AI_Channel_Config error = :" + err.ToString());
                    ret = false;
                }

                err = USBDASK.UD_DIO_1902_Config(Module_Num, USBDASK.GPI0_3_GPO0_1, USBDASK.GPI4_7_GPO2_3);
                if (err != USBDASK.NoError)
                {
                    this.m_InfoManager.Error("UD_DIO_1902_Config() Fail, Code:" + err.ToString());
                    ret = false;
                }
            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error(ex.ToString());
                ret = false;
            }

            return ret;
        }

        public void Close()
        {
            if (Module_Num != USBDASK.INVALID_CARD_ID)
            {
                USBDASK.UD_Release_Card(Module_Num);
            }
        }

        public void SendVoltage(double o_Value)
        {
            try
            {
                if (o_Value < 0)
                {
                   this.m_InfoManager.Error("Value < 0, set to 0");
                    o_Value = 0;
                }
                else if (o_Value > 10)
                {
                    this.m_InfoManager.Error("Value > 10, set to 10");
                    o_Value = 10;
                }

                ushort tmpAOCH = 0;
                double tmpAOValue = o_Value;
                USBDASK.UD_AO_VWriteChannel(Module_Num, tmpAOCH, tmpAOValue);
            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error(ex.ToString());
            }
        }


    }


}
