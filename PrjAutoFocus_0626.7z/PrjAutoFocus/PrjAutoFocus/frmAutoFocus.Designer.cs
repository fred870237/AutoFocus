﻿
namespace PrjAutoFocus
{
    partial class frmAutoFocus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.btnSendVoltage = new System.Windows.Forms.Button();
            this.txtMeasureDistance = new System.Windows.Forms.TextBox();
            this.tabLog = new System.Windows.Forms.TabControl();
            this.tpLogSystem = new System.Windows.Forms.TabPage();
            this.rtfLogSystem = new System.Windows.Forms.RichTextBox();
            this.tpLogError = new System.Windows.Forms.TabPage();
            this.rtfLogError = new System.Windows.Forms.RichTextBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.btnDisConnect = new System.Windows.Forms.Button();
            this.btnGetDistance = new System.Windows.Forms.Button();
            this.txtVoltage = new System.Windows.Forms.TextBox();
            this.lblMeasureDistance = new System.Windows.Forms.Label();
            this.lblVoltage = new System.Windows.Forms.Label();
            this.txtFactorA = new System.Windows.Forms.TextBox();
            this.txtFactorB = new System.Windows.Forms.TextBox();
            this.lblTitleX = new System.Windows.Forms.Label();
            this.lblTitleY = new System.Windows.Forms.Label();
            this.lblFormula = new System.Windows.Forms.Label();
            this.btnCalculateVoltage = new System.Windows.Forms.Button();
            this.lblDefaultDistance = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.colVoltage = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDistance = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colShiftToCenter = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nudDefaultDistance = new System.Windows.Forms.NumericUpDown();
            this.btnSaveRecipe = new System.Windows.Forms.Button();
            this.btnLoadConfig = new System.Windows.Forms.Button();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btnCalibate = new System.Windows.Forms.Button();
            this.btnAutoCompensated = new System.Windows.Forms.Button();
            this.gbxStepCompensated = new System.Windows.Forms.GroupBox();
            this.gbxClickCompensated = new System.Windows.Forms.GroupBox();
            this.btnClickCompensated = new System.Windows.Forms.Button();
            this.gbxAutoCompensated = new System.Windows.Forms.GroupBox();
            this.tabLog.SuspendLayout();
            this.tpLogSystem.SuspendLayout();
            this.tpLogError.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDefaultDistance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.gbxStepCompensated.SuspendLayout();
            this.gbxClickCompensated.SuspendLayout();
            this.gbxAutoCompensated.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSendVoltage
            // 
            this.btnSendVoltage.Location = new System.Drawing.Point(6, 104);
            this.btnSendVoltage.Name = "btnSendVoltage";
            this.btnSendVoltage.Size = new System.Drawing.Size(90, 30);
            this.btnSendVoltage.TabIndex = 3;
            this.btnSendVoltage.Text = "Send Voltage";
            this.btnSendVoltage.UseVisualStyleBackColor = true;
            this.btnSendVoltage.Click += new System.EventHandler(this.btnSendVoltage_Click);
            // 
            // txtMeasureDistance
            // 
            this.txtMeasureDistance.Location = new System.Drawing.Point(198, 6);
            this.txtMeasureDistance.Name = "txtMeasureDistance";
            this.txtMeasureDistance.Size = new System.Drawing.Size(77, 22);
            this.txtMeasureDistance.TabIndex = 1;
            this.txtMeasureDistance.Text = "0";
            // 
            // tabLog
            // 
            this.tabLog.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.tabLog.Controls.Add(this.tpLogSystem);
            this.tabLog.Controls.Add(this.tpLogError);
            this.tabLog.Location = new System.Drawing.Point(12, 262);
            this.tabLog.Name = "tabLog";
            this.tabLog.SelectedIndex = 0;
            this.tabLog.Size = new System.Drawing.Size(400, 287);
            this.tabLog.TabIndex = 2;
            // 
            // tpLogSystem
            // 
            this.tpLogSystem.BackColor = System.Drawing.Color.Transparent;
            this.tpLogSystem.Controls.Add(this.rtfLogSystem);
            this.tpLogSystem.Location = new System.Drawing.Point(4, 24);
            this.tpLogSystem.Name = "tpLogSystem";
            this.tpLogSystem.Padding = new System.Windows.Forms.Padding(3);
            this.tpLogSystem.Size = new System.Drawing.Size(392, 259);
            this.tpLogSystem.TabIndex = 0;
            this.tpLogSystem.Text = "System";
            // 
            // rtfLogSystem
            // 
            this.rtfLogSystem.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rtfLogSystem.BackColor = System.Drawing.SystemColors.Info;
            this.rtfLogSystem.Location = new System.Drawing.Point(0, 0);
            this.rtfLogSystem.Name = "rtfLogSystem";
            this.rtfLogSystem.Size = new System.Drawing.Size(389, 259);
            this.rtfLogSystem.TabIndex = 5;
            this.rtfLogSystem.Text = "";
            // 
            // tpLogError
            // 
            this.tpLogError.BackColor = System.Drawing.Color.Transparent;
            this.tpLogError.Controls.Add(this.rtfLogError);
            this.tpLogError.Location = new System.Drawing.Point(4, 24);
            this.tpLogError.Name = "tpLogError";
            this.tpLogError.Size = new System.Drawing.Size(392, 259);
            this.tpLogError.TabIndex = 1;
            this.tpLogError.Text = "Error";
            // 
            // rtfLogError
            // 
            this.rtfLogError.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rtfLogError.BackColor = System.Drawing.SystemColors.Info;
            this.rtfLogError.Location = new System.Drawing.Point(0, 0);
            this.rtfLogError.Name = "rtfLogError";
            this.rtfLogError.Size = new System.Drawing.Size(389, 259);
            this.rtfLogError.TabIndex = 6;
            this.rtfLogError.Text = "";
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(9, 12);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(75, 30);
            this.btnConnect.TabIndex = 0;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // btnDisConnect
            // 
            this.btnDisConnect.Location = new System.Drawing.Point(9, 48);
            this.btnDisConnect.Name = "btnDisConnect";
            this.btnDisConnect.Size = new System.Drawing.Size(75, 30);
            this.btnDisConnect.TabIndex = 4;
            this.btnDisConnect.Text = "DisConnect";
            this.btnDisConnect.UseVisualStyleBackColor = true;
            this.btnDisConnect.Click += new System.EventHandler(this.btnDisConnect_Click);
            // 
            // btnGetDistance
            // 
            this.btnGetDistance.Location = new System.Drawing.Point(6, 32);
            this.btnGetDistance.Name = "btnGetDistance";
            this.btnGetDistance.Size = new System.Drawing.Size(90, 30);
            this.btnGetDistance.TabIndex = 5;
            this.btnGetDistance.Text = "Get Distance";
            this.btnGetDistance.UseVisualStyleBackColor = true;
            this.btnGetDistance.Click += new System.EventHandler(this.btnGetDistance_Click);
            // 
            // txtVoltage
            // 
            this.txtVoltage.Location = new System.Drawing.Point(198, 34);
            this.txtVoltage.Name = "txtVoltage";
            this.txtVoltage.Size = new System.Drawing.Size(77, 22);
            this.txtVoltage.TabIndex = 6;
            this.txtVoltage.Text = "0";
            this.txtVoltage.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TxtVoltage_KeyDown);
            // 
            // lblMeasureDistance
            // 
            this.lblMeasureDistance.AutoSize = true;
            this.lblMeasureDistance.Location = new System.Drawing.Point(93, 9);
            this.lblMeasureDistance.Name = "lblMeasureDistance";
            this.lblMeasureDistance.Size = new System.Drawing.Size(99, 15);
            this.lblMeasureDistance.TabIndex = 7;
            this.lblMeasureDistance.Text = "Measure Distance";
            // 
            // lblVoltage
            // 
            this.lblVoltage.AutoSize = true;
            this.lblVoltage.Location = new System.Drawing.Point(145, 37);
            this.lblVoltage.Name = "lblVoltage";
            this.lblVoltage.Size = new System.Drawing.Size(47, 15);
            this.lblVoltage.TabIndex = 8;
            this.lblVoltage.Text = "Voltage";
            // 
            // txtFactorA
            // 
            this.txtFactorA.Location = new System.Drawing.Point(864, 463);
            this.txtFactorA.Name = "txtFactorA";
            this.txtFactorA.Size = new System.Drawing.Size(70, 22);
            this.txtFactorA.TabIndex = 9;
            this.txtFactorA.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtFactorB
            // 
            this.txtFactorB.Location = new System.Drawing.Point(759, 463);
            this.txtFactorB.Name = "txtFactorB";
            this.txtFactorB.Size = new System.Drawing.Size(70, 22);
            this.txtFactorB.TabIndex = 10;
            this.txtFactorB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblTitleX
            // 
            this.lblTitleX.AutoSize = true;
            this.lblTitleX.Location = new System.Drawing.Point(835, 466);
            this.lblTitleX.Name = "lblTitleX";
            this.lblTitleX.Size = new System.Drawing.Size(23, 15);
            this.lblTitleX.TabIndex = 11;
            this.lblTitleX.Text = "x +";
            // 
            // lblTitleY
            // 
            this.lblTitleY.AutoSize = true;
            this.lblTitleY.Location = new System.Drawing.Point(726, 466);
            this.lblTitleY.Name = "lblTitleY";
            this.lblTitleY.Size = new System.Drawing.Size(27, 15);
            this.lblTitleY.TabIndex = 12;
            this.lblTitleY.Text = "y = ";
            // 
            // lblFormula
            // 
            this.lblFormula.AutoSize = true;
            this.lblFormula.Location = new System.Drawing.Point(726, 442);
            this.lblFormula.Name = "lblFormula";
            this.lblFormula.Size = new System.Drawing.Size(189, 15);
            this.lblFormula.TabIndex = 13;
            this.lblFormula.Text = "Voltage = FactorB * Shift + FactorA";
            // 
            // btnCalculateVoltage
            // 
            this.btnCalculateVoltage.Location = new System.Drawing.Point(6, 68);
            this.btnCalculateVoltage.Name = "btnCalculateVoltage";
            this.btnCalculateVoltage.Size = new System.Drawing.Size(90, 30);
            this.btnCalculateVoltage.TabIndex = 14;
            this.btnCalculateVoltage.Text = "Calc Voltage";
            this.btnCalculateVoltage.UseVisualStyleBackColor = true;
            this.btnCalculateVoltage.Click += new System.EventHandler(this.btnCalculateVoltage_Click);
            // 
            // lblDefaultDistance
            // 
            this.lblDefaultDistance.AutoSize = true;
            this.lblDefaultDistance.Location = new System.Drawing.Point(391, 9);
            this.lblDefaultDistance.Name = "lblDefaultDistance";
            this.lblDefaultDistance.Size = new System.Drawing.Size(92, 15);
            this.lblDefaultDistance.TabIndex = 16;
            this.lblDefaultDistance.Text = "Default Distance";
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("微軟正黑體", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colVoltage,
            this.colDistance,
            this.colShiftToCenter});
            this.dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dataGridView1.Location = new System.Drawing.Point(418, 35);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 50;
            this.dataGridView1.Size = new System.Drawing.Size(299, 514);
            this.dataGridView1.TabIndex = 17;
            // 
            // colVoltage
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colVoltage.DefaultCellStyle = dataGridViewCellStyle2;
            this.colVoltage.HeaderText = "Voltage";
            this.colVoltage.Name = "colVoltage";
            this.colVoltage.Width = 80;
            // 
            // colDistance
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colDistance.DefaultCellStyle = dataGridViewCellStyle3;
            this.colDistance.HeaderText = "Distance";
            this.colDistance.Name = "colDistance";
            this.colDistance.Width = 80;
            // 
            // colShiftToCenter
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colShiftToCenter.DefaultCellStyle = dataGridViewCellStyle4;
            this.colShiftToCenter.HeaderText = "Shift";
            this.colShiftToCenter.Name = "colShiftToCenter";
            this.colShiftToCenter.ReadOnly = true;
            this.colShiftToCenter.Width = 80;
            // 
            // nudDefaultDistance
            // 
            this.nudDefaultDistance.DecimalPlaces = 4;
            this.nudDefaultDistance.Increment = new decimal(new int[] {
            1,
            0,
            0,
            262144});
            this.nudDefaultDistance.Location = new System.Drawing.Point(489, 7);
            this.nudDefaultDistance.Name = "nudDefaultDistance";
            this.nudDefaultDistance.Size = new System.Drawing.Size(89, 22);
            this.nudDefaultDistance.TabIndex = 18;
            this.nudDefaultDistance.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nudDefaultDistance.Value = new decimal(new int[] {
            5,
            0,
            0,
            262144});
            // 
            // btnSaveRecipe
            // 
            this.btnSaveRecipe.Location = new System.Drawing.Point(9, 84);
            this.btnSaveRecipe.Name = "btnSaveRecipe";
            this.btnSaveRecipe.Size = new System.Drawing.Size(75, 40);
            this.btnSaveRecipe.TabIndex = 19;
            this.btnSaveRecipe.Text = "Save Config";
            this.btnSaveRecipe.UseVisualStyleBackColor = true;
            this.btnSaveRecipe.Click += new System.EventHandler(this.btnSaveRecipe_Click);
            // 
            // btnLoadConfig
            // 
            this.btnLoadConfig.Location = new System.Drawing.Point(9, 130);
            this.btnLoadConfig.Name = "btnLoadConfig";
            this.btnLoadConfig.Size = new System.Drawing.Size(75, 40);
            this.btnLoadConfig.TabIndex = 20;
            this.btnLoadConfig.Text = "Load Config";
            this.btnLoadConfig.UseVisualStyleBackColor = true;
            this.btnLoadConfig.Click += new System.EventHandler(this.btnLoadConfig_Click);
            // 
            // chart1
            // 
            this.chart1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            chartArea1.AxisX.LabelStyle.Format = "N4";
            chartArea1.AxisX.Title = "Shift (mm)";
            chartArea1.AxisY.Title = "Voltage (V)";
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Enabled = false;
            legend1.Font = new System.Drawing.Font("微軟正黑體", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            legend1.IsTextAutoFit = false;
            legend1.Name = "Legend1";
            legend1.Title = "Shift-Voltage Ratio";
            legend1.TitleFont = new System.Drawing.Font("微軟正黑體", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(723, 35);
            this.chart1.Name = "chart1";
            series1.BorderWidth = 2;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Color = System.Drawing.Color.DodgerBlue;
            series1.Legend = "Legend1";
            series1.MarkerColor = System.Drawing.Color.Orange;
            series1.MarkerSize = 4;
            series1.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Square;
            series1.Name = "Series1";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(361, 355);
            this.chart1.TabIndex = 21;
            this.chart1.Text = "chart1";
            title1.Name = "Title1";
            title1.Text = "Shift-Voltage Ratio";
            this.chart1.Titles.Add(title1);
            // 
            // btnCalibate
            // 
            this.btnCalibate.BackColor = System.Drawing.Color.Orange;
            this.btnCalibate.Location = new System.Drawing.Point(726, 396);
            this.btnCalibate.Name = "btnCalibate";
            this.btnCalibate.Size = new System.Drawing.Size(75, 40);
            this.btnCalibate.TabIndex = 22;
            this.btnCalibate.Text = "Calibrate";
            this.btnCalibate.UseVisualStyleBackColor = false;
            this.btnCalibate.Click += new System.EventHandler(this.btnCalibate_Click);
            // 
            // btnAutoCompensated
            // 
            this.btnAutoCompensated.BackColor = System.Drawing.Color.Green;
            this.btnAutoCompensated.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnAutoCompensated.Location = new System.Drawing.Point(6, 32);
            this.btnAutoCompensated.Name = "btnAutoCompensated";
            this.btnAutoCompensated.Size = new System.Drawing.Size(90, 59);
            this.btnAutoCompensated.TabIndex = 23;
            this.btnAutoCompensated.Text = "Start";
            this.btnAutoCompensated.UseVisualStyleBackColor = false;
            this.btnAutoCompensated.Click += new System.EventHandler(this.BtnAutoCompensated_Click);
            // 
            // gbxStepCompensated
            // 
            this.gbxStepCompensated.Controls.Add(this.btnGetDistance);
            this.gbxStepCompensated.Controls.Add(this.btnCalculateVoltage);
            this.gbxStepCompensated.Controls.Add(this.btnSendVoltage);
            this.gbxStepCompensated.Location = new System.Drawing.Point(90, 62);
            this.gbxStepCompensated.Name = "gbxStepCompensated";
            this.gbxStepCompensated.Size = new System.Drawing.Size(104, 147);
            this.gbxStepCompensated.TabIndex = 24;
            this.gbxStepCompensated.TabStop = false;
            this.gbxStepCompensated.Text = "Step Compensated";
            // 
            // gbxClickCompensated
            // 
            this.gbxClickCompensated.Controls.Add(this.btnClickCompensated);
            this.gbxClickCompensated.Location = new System.Drawing.Point(200, 62);
            this.gbxClickCompensated.Name = "gbxClickCompensated";
            this.gbxClickCompensated.Size = new System.Drawing.Size(104, 147);
            this.gbxClickCompensated.TabIndex = 25;
            this.gbxClickCompensated.TabStop = false;
            this.gbxClickCompensated.Text = "Click Compensated";
            // 
            // btnClickCompensated
            // 
            this.btnClickCompensated.BackColor = System.Drawing.Color.Orange;
            this.btnClickCompensated.Location = new System.Drawing.Point(6, 32);
            this.btnClickCompensated.Name = "btnClickCompensated";
            this.btnClickCompensated.Size = new System.Drawing.Size(90, 59);
            this.btnClickCompensated.TabIndex = 24;
            this.btnClickCompensated.Text = "Click Compensated";
            this.btnClickCompensated.UseVisualStyleBackColor = false;
            this.btnClickCompensated.Click += new System.EventHandler(this.BtnClickCompensated_Click);
            // 
            // gbxAutoCompensated
            // 
            this.gbxAutoCompensated.Controls.Add(this.btnAutoCompensated);
            this.gbxAutoCompensated.Location = new System.Drawing.Point(310, 62);
            this.gbxAutoCompensated.Name = "gbxAutoCompensated";
            this.gbxAutoCompensated.Size = new System.Drawing.Size(104, 147);
            this.gbxAutoCompensated.TabIndex = 26;
            this.gbxAutoCompensated.TabStop = false;
            this.gbxAutoCompensated.Text = "Auto Compensated";
            // 
            // frmAutoFocus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1094, 561);
            this.Controls.Add(this.gbxAutoCompensated);
            this.Controls.Add(this.gbxClickCompensated);
            this.Controls.Add(this.gbxStepCompensated);
            this.Controls.Add(this.btnCalibate);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.btnLoadConfig);
            this.Controls.Add(this.btnSaveRecipe);
            this.Controls.Add(this.nudDefaultDistance);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblDefaultDistance);
            this.Controls.Add(this.lblFormula);
            this.Controls.Add(this.lblTitleY);
            this.Controls.Add(this.lblTitleX);
            this.Controls.Add(this.txtFactorB);
            this.Controls.Add(this.txtFactorA);
            this.Controls.Add(this.lblVoltage);
            this.Controls.Add(this.lblMeasureDistance);
            this.Controls.Add(this.txtVoltage);
            this.Controls.Add(this.btnDisConnect);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.tabLog);
            this.Controls.Add(this.txtMeasureDistance);
            this.Font = new System.Drawing.Font("微軟正黑體", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Name = "frmAutoFocus";
            this.Text = "frmAutoFocus";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmAutoFocus_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmAutoFocus_FormClosed);
            this.Load += new System.EventHandler(this.frmAutoFocus_Load);
            this.Resize += new System.EventHandler(this.frmAutoFocus_Resize);
            this.tabLog.ResumeLayout(false);
            this.tpLogSystem.ResumeLayout(false);
            this.tpLogError.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDefaultDistance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.gbxStepCompensated.ResumeLayout(false);
            this.gbxClickCompensated.ResumeLayout(false);
            this.gbxAutoCompensated.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSendVoltage;
        private System.Windows.Forms.TextBox txtMeasureDistance;
        private System.Windows.Forms.TabControl tabLog;
        private System.Windows.Forms.TabPage tpLogSystem;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Button btnDisConnect;
        private System.Windows.Forms.TabPage tpLogError;
        private System.Windows.Forms.RichTextBox rtfLogSystem;
        private System.Windows.Forms.RichTextBox rtfLogError;
        private System.Windows.Forms.Button btnGetDistance;
        private System.Windows.Forms.TextBox txtVoltage;
        private System.Windows.Forms.Label lblMeasureDistance;
        private System.Windows.Forms.Label lblVoltage;
        private System.Windows.Forms.TextBox txtFactorA;
        private System.Windows.Forms.TextBox txtFactorB;
        private System.Windows.Forms.Label lblTitleX;
        private System.Windows.Forms.Label lblTitleY;
        private System.Windows.Forms.Label lblFormula;
        private System.Windows.Forms.Button btnCalculateVoltage;
        private System.Windows.Forms.Label lblDefaultDistance;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.NumericUpDown nudDefaultDistance;
        private System.Windows.Forms.DataGridViewTextBoxColumn colVoltage;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDistance;
        private System.Windows.Forms.DataGridViewTextBoxColumn colShiftToCenter;
        private System.Windows.Forms.Button btnSaveRecipe;
        private System.Windows.Forms.Button btnLoadConfig;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Button btnCalibate;
        private System.Windows.Forms.Button btnAutoCompensated;
        private System.Windows.Forms.GroupBox gbxStepCompensated;
        private System.Windows.Forms.GroupBox gbxClickCompensated;
        private System.Windows.Forms.GroupBox gbxAutoCompensated;
        private System.Windows.Forms.Button btnClickCompensated;
    }
}