﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;

namespace PrjAutoFocus.Class
{
    public partial class ClsSerialPortConfig : CommonBase.Config.BaseConfig<ClsSerialPortConfig>
    {
        private string classVersion = "BestintechConfig_201911281136";

        public bool m_Enable;
        public string m_PortName;
        public int m_BaudRate;
        public int m_Parity;
        public int m_DataBits;
        public int m_StopBits;
        public int m_ReadTimeout;

        public ClsSerialPortConfig()
        {
            this.m_Enable = true;
            this.m_PortName = "COM1";
            this.m_BaudRate = 115200;
            this.m_Parity = 1;
            this.m_DataBits = 8;
            this.m_StopBits = 1;
            this.m_ReadTimeout = 3000;
        }

        protected override bool CheckValue(ClsSerialPortConfig tmpConfig)
		{
			// ...
			this.m_Enable = tmpConfig.m_Enable;
            this.m_PortName = tmpConfig.m_PortName;
            this.m_BaudRate = tmpConfig.m_BaudRate;
            this.m_Parity = tmpConfig.m_Parity;
            this.m_DataBits = tmpConfig.m_DataBits;
            this.m_StopBits = tmpConfig.m_StopBits;
            this.m_ReadTimeout = tmpConfig.m_ReadTimeout;

			//	Read UPDATE
			this.Update = tmpConfig.Update;

			//	Read VERSION
			this.Version = this.classVersion;

			if (this.Version != tmpConfig.Version)
				return false;
			else
				return true;
        }
    }

    class ClsSerialPortControl
    {
        private CommonBase.Logger.InfoManager m_InfoManager;

        private ClsSerialPortConfig m_ClsSerialPortConfig;

        private System.IO.Ports.SerialPort m_SerialPort;

        private double m_currentDistance;

        public ClsSerialPortControl(
            ClsSerialPortConfig o_ClsSerialPortConfig,
            CommonBase.Logger.InfoManager o_InfoManager)
        {
            //
            this.m_ClsSerialPortConfig = o_ClsSerialPortConfig;

            //
            this.m_InfoManager = o_InfoManager;

            //
            this.m_SerialPort = new System.IO.Ports.SerialPort();
            this.m_SerialPort.PortName = m_ClsSerialPortConfig.m_PortName;
            this.m_SerialPort.BaudRate = m_ClsSerialPortConfig.m_BaudRate;
            this.m_SerialPort.Parity = (Parity)m_ClsSerialPortConfig.m_Parity;
            this.m_SerialPort.DataBits = m_ClsSerialPortConfig.m_DataBits;
            this.m_SerialPort.StopBits = (StopBits)m_ClsSerialPortConfig.m_StopBits;
            this.m_SerialPort.ReadTimeout = m_ClsSerialPortConfig.m_ReadTimeout;
            this.m_SerialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);

            //
            this.m_currentDistance = 0.0;
        }

        private void DataReceivedHandler(
            Object sender,
            SerialDataReceivedEventArgs e)
        {
            SerialPort temp_SerialPort = (SerialPort)sender;
            if (temp_SerialPort.BytesToRead > 0)
            {
                Byte[] buffer = new Byte[1024];
                int length = temp_SerialPort.Read(buffer, 0, buffer.Length);
                Array.Resize(ref buffer, length);

                //string indata = temp_SerialPort.ReadExisting();

                //Display in InfoLog.
                this.m_InfoManager.General(System.Text.Encoding.Default.GetString(buffer));

                //
                try
                {
                    string tmpStr = System.Text.Encoding.ASCII.GetString(buffer);
                    this.m_currentDistance = Convert.ToDouble(tmpStr.Trim());
                }
                catch (Exception ex)
                {
                    this.m_InfoManager.Error(ex.ToString());
                }
            }
        }

        public double GetCurrentDistance()
        {
            // nm
            return this.m_currentDistance;
        }

        public bool Open()
        {
            if (this.m_ClsSerialPortConfig.m_Enable)
            {
                if (this.m_SerialPort != null &&
                    !this.m_SerialPort.IsOpen)
                {
                    try
                    {
                        this.m_SerialPort.Open();
                    }
                    catch (Exception ex)
                    {
                        this.m_InfoManager.Error(ex.ToString());
                        return false;
                    }
                }
                else
                {
                    // the serial port is open.
                }
            }

            return true;
        }

        public void Send(string o_Msg)
        {
            //
            if (this.m_ClsSerialPortConfig.m_Enable)
            {
                if (this.m_SerialPort != null &&
                    this.m_SerialPort.IsOpen)
                {
                    this.m_SerialPort.WriteLine(o_Msg);
                }
            }
        }

        public void Close()
        {
            //
            if (this.m_ClsSerialPortConfig.m_Enable)
            {
                if (this.m_SerialPort != null &&
                    this.m_SerialPort.IsOpen)
                {
                    try
                    {
                        this.m_SerialPort.Close();
                    }
                    catch (Exception ex)
                    {
                        this.m_InfoManager.Error(ex.ToString());
                    }
                }
            }

        }


    }

}
