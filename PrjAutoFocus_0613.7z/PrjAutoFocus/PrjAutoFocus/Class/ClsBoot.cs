﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrjAutoFocus.Class
{

    public delegate bool funcSendCoarseMsgToDACallBack(string o_ToDaMsg, int o_Position, ref double o_X, ref double o_Y, ref double o_Theta);

    public delegate bool funcSendFineMsgToDACallBack(string o_ToDaMsg, int o_Position, ref double o_X, ref double o_Y, ref double o_Theta);

    public delegate void funcChangeCurrentStatusCallBack(string o_Status);


    public static class Common
    {
        public static string APPLICATION_NAME = "AutoFocus_Software";
        public static string APPLICATION_VERSION = "V001";
        public static string APPLICATION_REVERSION = "21.0527.1610";
        public static string SOFTWARE_APP_VERSION = 
            (APPLICATION_NAME + "_" + APPLICATION_VERSION + "_" + APPLICATION_REVERSION);

        public static string CONFIG_FOLDER = System.Windows.Forms.Application.StartupPath + "\\CtrlConfig\\";
        public static string DEFAULT_CONFIG_FOLDER = System.Windows.Forms.Application.StartupPath + "\\DefaultCtrlConfig\\";

        public static string BOOT_CONFIG_NAME = "BootConfig.xml";
        //public static string NETWORK_CONFIG_NAME = "NetworkConfig.xml";
        //public static string PLC_CONFIG_NAME = "PlcConfig.xml";
        //public static string RECORD_CONFIG_NAME = "RecordConfig.xml";
        public static string SERIAL_PORT_CONFIG_NAME = "SerialPortConfig.xml";
        public static string DAQ_MODULE_CONFIG_NAME = "DaqModuleConfig.xml";

        //public static string RECORD_RESULT_NAME = "RecordResult.xml";
    }

    public struct _st_Calibration_Data_
    {
        public double voltage { get; set; }
        public double distance { get; set; }
    }

    public partial class ClsBootConfig : CommonBase.Config.BaseConfig<ClsBootConfig>
    {
        private string classVersion = "ClsBootConfig_202103191115";

        public string rootPath;

        // y = ax + b; 
        // voltage = factorA * distance + factorB;
        public double factorA;
        public double factorB;
        public double defaultDistance;
        public double offset;

        public double maxVoltage;
        public double minVoltage;

        public List<_st_Calibration_Data_> l_st_Calibration_Data_;

        public ClsBootConfig()
        {
            this.rootPath = ".\\AutoFocus";

            this.factorA = 0;
            this.factorB = 0;
            this.defaultDistance = 0;
            this.offset = 0;

            this.maxVoltage = 10;
            this.minVoltage = 0;

            this.l_st_Calibration_Data_ = new List<_st_Calibration_Data_> { };
        }

        protected override bool CheckValue(ClsBootConfig tmpConfig)
        {
            this.rootPath = tmpConfig.rootPath;

            this.factorA = tmpConfig.factorA;
            this.factorB = tmpConfig.factorB;
            this.defaultDistance = tmpConfig.defaultDistance;
            this.offset = tmpConfig.offset;

            this.maxVoltage = tmpConfig.maxVoltage;
            this.minVoltage = tmpConfig.minVoltage;

            this.l_st_Calibration_Data_ = tmpConfig.l_st_Calibration_Data_;

            //	Read UPDATE
            this.Update = tmpConfig.Update;

            //	Read VERSION
            this.Version = this.classVersion;

            if (this.Version != tmpConfig.Version)
                return false;
            else
                return true;
        }

    }
}
