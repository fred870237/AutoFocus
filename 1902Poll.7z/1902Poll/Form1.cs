using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace _902Poll
{
    public partial class Form1 : Form
    {
        ushort wSelModuleID;
        ushort wSelModuleType;
        ushort Module_Num;
        ushort wSelectedChans = 4;
        ushort[] AiBuf = new ushort[4];
        ushort[] ChanArray = new ushort[4];
        ushort[] GainArray = new ushort[4];
        uint m_InData0;
        uint m_InData1;
        uint m_OutData0;
        uint m_OutData1;
        ushort wIndex_X;
        int nMax_X;
        Point[] OldPointArray = new Point[4];
        Graphics gr;

        public Form1()
        {
            InitializeComponent();
            Module_Num = USBDASK.INVALID_CARD_ID;
            wSelModuleID = USBDASK.INVALID_CARD_ID;
        }
        public void SetModuleType(ushort ModuleType)
        {
            wSelModuleType = ModuleType;
        }
        public void SetModuleID(ushort ModuleID)
        {
            wSelModuleID = ModuleID;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            short iTemp;
            short err;
            ushort i;

            if (wSelModuleID == USBDASK.INVALID_CARD_ID)
                return;

            gr = pbxDisplay.CreateGraphics();
            nMax_X = pbxDisplay.Width;

            iTemp = USBDASK.UD_Register_Card(wSelModuleType, wSelModuleID);
            if (iTemp < 0)
            {
                MessageBox.Show("UD_Register_Card() Fail, Code:" + iTemp.ToString());
                Close();
                return;
            }

            textBox_CardID.Text = wSelModuleID.ToString();
            Module_Num = (ushort)iTemp;

            // Configure AI Channel
            err = USBDASK.UD_AI_1902_Config(Module_Num, USBDASK.P1902_AI_PseudoDifferential, 0, 0, 0, 0);
            if (err != USBDASK.NoError)
            {
                MessageBox.Show("UD_AI_Channel_Config error = :" + err.ToString());
                Close();
                return;
            }

            for (i = 0; i < wSelectedChans; i++)
            {
                ChanArray[i] = i;
                GainArray[i] = USBDASK.AD_B_10_V;
            }

            tbxYup.Text = "10V";
            tbxYdown.Text = "-10V";
            textYZero.Text = "0V";
            pbxDisplay.BackColor = Color.Black;

            err = USBDASK.UD_DIO_1902_Config(Module_Num, USBDASK.GPI0_3_GPO0_1, USBDASK.GPI4_7_GPO2_3);
            if (err != USBDASK.NoError)
            {
                MessageBox.Show("UD_DIO_1902_Config() Fail, Code:" + err.ToString());
                return;
            }

            m_OutData0 = 0x0000;
            m_OutData1 = 0x0000;
            m_InData0 = 0x0000;
            m_InData1 = 0x0000;

        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            gr.Dispose();

            if (timer1.Enabled == true)
            {
                timer1.Enabled = false;
            }

            if (Module_Num != USBDASK.INVALID_CARD_ID)
            {
                USBDASK.UD_Release_Card(Module_Num);
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            wIndex_X = 0;
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
        }

        private void PlotData()
        {
            float fScaleY, fMidY;
            ushort Cur_Channel;
            short I16Temp;
            ushort U16Temp;
            Point[] NewPoint = new Point[1];

            if( wIndex_X == 0 )
                pbxDisplay.Refresh();

            fScaleY = ((float)pbxDisplay.Height * (float)0.97) / (float)65536.0;
            fMidY = (float)pbxDisplay.Height / 2;

            NewPoint[0].X = (int)(wIndex_X);

            for (Cur_Channel = 0; Cur_Channel < wSelectedChans; Cur_Channel++)
            {
                U16Temp = (AiBuf[Cur_Channel]);

                I16Temp = (short)U16Temp;
                NewPoint[0].Y = (int)(fMidY - I16Temp * fScaleY);
                
                if( wIndex_X > 0 )
                {
                    switch (Cur_Channel)
                    {
                        case 0:
                            gr.DrawLine(Pens.Yellow, OldPointArray[Cur_Channel], NewPoint[0]);
                            break;
                        case 1:
                            gr.DrawLine(Pens.LightGreen, OldPointArray[Cur_Channel], NewPoint[0]);
                            break;
                        case 2:
                            gr.DrawLine(Pens.Blue, OldPointArray[Cur_Channel], NewPoint[0]);
                            break;
                        case 3:
                            gr.DrawLine(Pens.Red, OldPointArray[Cur_Channel], NewPoint[0]);
                            break;
                    }
                }

                OldPointArray[Cur_Channel] = NewPoint[0];
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            short err;
            uint dwPortData0, dwPortData1, dwChanMsk0, dwChanMsk1;

            err = USBDASK.UD_DI_ReadPort(Module_Num, 0, out dwPortData0);
            err = USBDASK.UD_DI_ReadPort(Module_Num, 1, out dwPortData1);

            dwChanMsk0 = dwPortData0 ^ m_InData0;
            dwChanMsk1 = dwPortData1 ^ m_InData1;

            if (dwChanMsk0 != 0x00) // Input had been changed 
            {

                m_InData0 = dwPortData0;

                if ((dwChanMsk0 & 0x0001) == 0x0001) // if the target bit is changed 
                {
                    if ((dwPortData0 & 0x0001) == 0x0001)
                        pbxIN0.BackColor = Color.Red;
                    else
                        pbxIN0.BackColor = Color.Black;
                }


                if ((dwChanMsk0 & 0x0002) == 0x0002) // if the target bit is changed 
                {
                    if ((dwPortData0 & 0x0002) == 0x0002)
                        pbxIN1.BackColor = Color.Red;
                    else
                        pbxIN1.BackColor = Color.Black;
                }

                if ((dwChanMsk0 & 0x0004) == 0x0004) // if the target bit is changed 
                {
                    if ((dwPortData0 & 0x0004) == 0x0004)
                        pbxIN2.BackColor = Color.Red;
                    else
                        pbxIN2.BackColor = Color.Black;
                }

                if ((dwChanMsk0 & 0x0008) == 0x0008) // if the target bit is changed 
                {
                    if ((dwPortData0 & 0x0008) == 0x0008)
                        pbxIN3.BackColor = Color.Red;
                    else
                        pbxIN3.BackColor = Color.Black;
                }

            }


            if (dwChanMsk1 != 0x00) // Input had been changed 
            {

                m_InData1 = dwPortData1;

                if ((dwChanMsk1 & 0x0001) == 0x0001) // if the target bit is changed 
                {
                    if ((dwPortData1 & 0x0001) == 0x0001)
                        pbxIN4.BackColor = Color.Red;
                    else
                        pbxIN4.BackColor = Color.Black;
                }


                if ((dwChanMsk1 & 0x0002) == 0x0002) // if the target bit is changed 
                {
                    if ((dwPortData1 & 0x0002) == 0x0002)
                        pbxIN5.BackColor = Color.Red;
                    else
                        pbxIN5.BackColor = Color.Black;
                }

                if ((dwChanMsk1 & 0x0004) == 0x0004) // if the target bit is changed 
                {
                    if ((dwPortData1 & 0x0004) == 0x0004)
                        pbxIN6.BackColor = Color.Red;
                    else
                        pbxIN6.BackColor = Color.Black;
                }

                if ((dwChanMsk1 & 0x0008) == 0x0008) // if the target bit is changed 
                {
                    if ((dwPortData1 & 0x0008) == 0x0008)
                        pbxIN7.BackColor = Color.Red;
                    else
                        pbxIN7.BackColor = Color.Black;
                }

            }



            err = USBDASK.UD_AI_ReadMultiChannels( Module_Num, wSelectedChans, ChanArray, GainArray, AiBuf );
            if (err != USBDASK.NoError)
            {
                timer1.Enabled = false;
                MessageBox.Show("UD_AI_ReadMultiChannels error = :" + err.ToString());
                return;
            }
            else
            {
                PlotData();

                wIndex_X++;
                if (wIndex_X >= nMax_X)
                    wIndex_X = 0;
            }
        }

        private void cbDO0_CheckedChanged(object sender, EventArgs e)
        {
            short err;

            if (cbDO0.Checked == true)
            {
                m_OutData0 |= 0x01;
            }
            else if (cbDO0.Checked == false)
            {
                m_OutData0 &= (0xFFFFFFFE);
            }

            err = USBDASK.UD_DO_WritePort(Module_Num, 0, m_OutData0);
        }

        private void cbDO1_CheckedChanged(object sender, EventArgs e)
        {
            short err;

            if (cbDO1.Checked == true)
            {
                m_OutData0 |= 0x02;
            }
            else if (cbDO1.Checked == false)
            {
                m_OutData0 &= (0xFFFFFFFD);
            }

            err = USBDASK.UD_DO_WritePort(Module_Num, 0, m_OutData0);
        }

        private void cbDO2_CheckedChanged(object sender, EventArgs e)
        {
            short err;

            if (cbDO2.Checked == true)
            {
                m_OutData1 |= 0x01;
            }
            else if (cbDO2.Checked == false)
            {
                m_OutData1 &= (0xFFFFFFFE);
            }

            err = USBDASK.UD_DO_WritePort(Module_Num, 1, m_OutData1);
        }

        private void cbDO3_CheckedChanged(object sender, EventArgs e)
        {
            short err;

            if (cbDO3.Checked == true)
            {
                m_OutData1 |= 0x02;
            }
            else if (cbDO3.Checked == false)
            {
                m_OutData1 &= (0xFFFFFFFD);
            }

            err = USBDASK.UD_DO_WritePort(Module_Num, 1, m_OutData1);
        }

        private void btnWriteAO_Click(object sender, EventArgs e)
        {
            ushort tmpAOCH = 0;
            double tmpAOValue = Convert.ToDouble(txtAOValue.Text);
            USBDASK.UD_AO_VWriteChannel(Module_Num, tmpAOCH, tmpAOValue);
        }
    }
}