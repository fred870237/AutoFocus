﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrjAutoFocus.Class
{

    public delegate bool funcSendCoarseMsgToDACallBack(string o_ToDaMsg, int o_Position, ref double o_X, ref double o_Y, ref double o_Theta);

    public delegate bool funcSendFineMsgToDACallBack(string o_ToDaMsg, int o_Position, ref double o_X, ref double o_Y, ref double o_Theta);

    public delegate void funcChangeCurrentStatusCallBack(string o_Status);


    public static class Common
    {
        public static string APPLICATION_NAME = "AutoFocus_Software";
        public static string APPLICATION_VERSION = "V001";
        public static string APPLICATION_REVERSION = "21.0527.1610";
        public static string SOFTWARE_APP_VERSION = 
            (APPLICATION_NAME + "_" + APPLICATION_VERSION + "_" + APPLICATION_REVERSION);

        public static string CONFIG_FOLDER = System.Windows.Forms.Application.StartupPath + "\\CtrlConfig\\";
        public static string DEFAULT_CONFIG_FOLDER = System.Windows.Forms.Application.StartupPath + "\\DefaultCtrlConfig\\";

        public static string BOOT_CONFIG_NAME = "BootConfig.xml";
        //public static string NETWORK_CONFIG_NAME = "NetworkConfig.xml";
        //public static string PLC_CONFIG_NAME = "PlcConfig.xml";
        //public static string RECORD_CONFIG_NAME = "RecordConfig.xml";
        public static string SERIALPORT_CONFIG_NAME = "SerialPortConfig.xml";

        //public static string RECORD_RESULT_NAME = "RecordResult.xml";
    }

    public partial class ClsBootConfig : CommonBase.Config.BaseConfig<ClsBootConfig>
    {
        private string classVersion = "ClsBootConfig_202103191115";

        public string rootPath;

        public ClsBootConfig()
        {
            this.rootPath = ".\\AutoFocus";
        }
        protected override bool CheckValue(ClsBootConfig tmpConfig)
        {
            this.rootPath = tmpConfig.rootPath;

            //	Read UPDATE
            this.Update = tmpConfig.Update;

            //	Read VERSION
            this.Version = this.classVersion;

            if (this.Version != tmpConfig.Version)
                return false;
            else
                return true;
        }

    }
}
