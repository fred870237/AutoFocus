﻿
namespace PrjAutoFocus
{
    partial class frmAutoFocus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSendVoltage = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tabLog = new System.Windows.Forms.TabControl();
            this.tpLogSystem = new System.Windows.Forms.TabPage();
            this.rtfLogSystem = new System.Windows.Forms.RichTextBox();
            this.tpLogError = new System.Windows.Forms.TabPage();
            this.rtfLogError = new System.Windows.Forms.RichTextBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.btnDisConnect = new System.Windows.Forms.Button();
            this.btnGetDistance = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.tabLog.SuspendLayout();
            this.tpLogSystem.SuspendLayout();
            this.tpLogError.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSendVoltage
            // 
            this.btnSendVoltage.Location = new System.Drawing.Point(90, 48);
            this.btnSendVoltage.Name = "btnSendVoltage";
            this.btnSendVoltage.Size = new System.Drawing.Size(85, 30);
            this.btnSendVoltage.TabIndex = 3;
            this.btnSendVoltage.Text = "Send Voltage";
            this.btnSendVoltage.UseVisualStyleBackColor = true;
            this.btnSendVoltage.Click += new System.EventHandler(this.btnSendVoltage_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(276, 17);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(153, 22);
            this.textBox1.TabIndex = 1;
            // 
            // tabLog
            // 
            this.tabLog.Controls.Add(this.tpLogSystem);
            this.tabLog.Controls.Add(this.tpLogError);
            this.tabLog.Location = new System.Drawing.Point(12, 125);
            this.tabLog.Name = "tabLog";
            this.tabLog.SelectedIndex = 0;
            this.tabLog.Size = new System.Drawing.Size(468, 213);
            this.tabLog.TabIndex = 2;
            // 
            // tpLogSystem
            // 
            this.tpLogSystem.BackColor = System.Drawing.Color.Transparent;
            this.tpLogSystem.Controls.Add(this.rtfLogSystem);
            this.tpLogSystem.Location = new System.Drawing.Point(4, 24);
            this.tpLogSystem.Name = "tpLogSystem";
            this.tpLogSystem.Padding = new System.Windows.Forms.Padding(3);
            this.tpLogSystem.Size = new System.Drawing.Size(460, 185);
            this.tpLogSystem.TabIndex = 0;
            this.tpLogSystem.Text = "System";
            // 
            // rtfLogSystem
            // 
            this.rtfLogSystem.BackColor = System.Drawing.SystemColors.Info;
            this.rtfLogSystem.Location = new System.Drawing.Point(0, 0);
            this.rtfLogSystem.Name = "rtfLogSystem";
            this.rtfLogSystem.Size = new System.Drawing.Size(460, 185);
            this.rtfLogSystem.TabIndex = 5;
            this.rtfLogSystem.Text = "";
            // 
            // tpLogError
            // 
            this.tpLogError.BackColor = System.Drawing.Color.Transparent;
            this.tpLogError.Controls.Add(this.rtfLogError);
            this.tpLogError.Location = new System.Drawing.Point(4, 24);
            this.tpLogError.Name = "tpLogError";
            this.tpLogError.Size = new System.Drawing.Size(460, 185);
            this.tpLogError.TabIndex = 1;
            this.tpLogError.Text = "Error";
            // 
            // rtfLogError
            // 
            this.rtfLogError.BackColor = System.Drawing.SystemColors.Info;
            this.rtfLogError.Location = new System.Drawing.Point(0, 0);
            this.rtfLogError.Name = "rtfLogError";
            this.rtfLogError.Size = new System.Drawing.Size(460, 185);
            this.rtfLogError.TabIndex = 6;
            this.rtfLogError.Text = "";
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(9, 12);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(75, 30);
            this.btnConnect.TabIndex = 0;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // btnDisConnect
            // 
            this.btnDisConnect.Location = new System.Drawing.Point(9, 48);
            this.btnDisConnect.Name = "btnDisConnect";
            this.btnDisConnect.Size = new System.Drawing.Size(75, 30);
            this.btnDisConnect.TabIndex = 4;
            this.btnDisConnect.Text = "DisConnect";
            this.btnDisConnect.UseVisualStyleBackColor = true;
            this.btnDisConnect.Click += new System.EventHandler(this.btnDisConnect_Click);
            // 
            // btnGetDistance
            // 
            this.btnGetDistance.Location = new System.Drawing.Point(90, 12);
            this.btnGetDistance.Name = "btnGetDistance";
            this.btnGetDistance.Size = new System.Drawing.Size(85, 30);
            this.btnGetDistance.TabIndex = 5;
            this.btnGetDistance.Text = "Get Distance";
            this.btnGetDistance.UseVisualStyleBackColor = true;
            this.btnGetDistance.Click += new System.EventHandler(this.btnGetDistance_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(276, 53);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(153, 22);
            this.textBox2.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(219, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 15);
            this.label1.TabIndex = 7;
            this.label1.Text = "Distance";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(219, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 15);
            this.label2.TabIndex = 8;
            this.label2.Text = "Voltage";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(276, 81);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(70, 22);
            this.textBox3.TabIndex = 9;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(359, 81);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(70, 22);
            this.textBox4.TabIndex = 10;
            // 
            // frmAutoFocus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(492, 350);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.btnGetDistance);
            this.Controls.Add(this.btnDisConnect);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.tabLog);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnSendVoltage);
            this.Font = new System.Drawing.Font("微軟正黑體", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Name = "frmAutoFocus";
            this.Text = "frmAutoFocus";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmAutoFocus_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmAutoFocus_FormClosed);
            this.Load += new System.EventHandler(this.frmAutoFocus_Load);
            this.tabLog.ResumeLayout(false);
            this.tpLogSystem.ResumeLayout(false);
            this.tpLogError.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSendVoltage;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TabControl tabLog;
        private System.Windows.Forms.TabPage tpLogSystem;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Button btnDisConnect;
        private System.Windows.Forms.TabPage tpLogError;
        private System.Windows.Forms.RichTextBox rtfLogSystem;
        private System.Windows.Forms.RichTextBox rtfLogError;
        private System.Windows.Forms.Button btnGetDistance;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
    }
}