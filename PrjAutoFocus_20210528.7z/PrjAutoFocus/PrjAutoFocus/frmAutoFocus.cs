﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PrjAutoFocus.Class;

namespace PrjAutoFocus
{
    public partial class frmAutoFocus : Form
    {
        // Config
        private ClsBootConfig g_ClsBootConfig = null;
        private ClsSerialPortConfig g_ClsSerialPortConfig = null;

        // Control
        private ClsSerialPortControl g_ClsSerialPortControl = null;


        // Log
        private CommonBase.Logger.InfoManager g_InfoManager;



        public frmAutoFocus()
        {
            InitializeComponent();
        }

        private void frmAutoFocus_Load(object sender, EventArgs e)
        {
            this.Text = Common.SOFTWARE_APP_VERSION;


            // log 
            // controller
            try
            {
                this.g_InfoManager = new CommonBase.Logger.InfoManager(
                    this.g_ClsBootConfig.rootPath + "\\Log\\systemlog",
                    this.g_ClsBootConfig.rootPath + "\\Log\\networklog",
                    this.g_ClsBootConfig.rootPath + "\\Log\\warninglog",
                    this.g_ClsBootConfig.rootPath + "\\Log\\errorlog",
                    this.g_ClsBootConfig.rootPath + "\\Log\\debuglog");

                this.g_InfoManager.SetGeneralTextBox(ref this.rtfLogSystem);
                this.g_InfoManager.SetErrorTextBox(ref this.rtfLogError);
            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
            }

        }

        private void frmAutoFocus_FormClosed(object sender, FormClosedEventArgs e)
        {
            // log
            try
            {
                if (this.g_InfoManager != null) this.g_InfoManager.Dispose();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        private void frmAutoFocus_FormClosing(object sender, FormClosingEventArgs e)
        {

        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            int ret = 0;

            // connect gap sensor
            try
            {

                //
                if (this.g_ClsSerialPortConfig != null) { this.g_ClsSerialPortConfig = null; }
                this.g_ClsSerialPortConfig = new ClsSerialPortConfig();

                if (System.IO.File.Exists(Common.CONFIG_FOLDER + Common.SERIALPORT_CONFIG_NAME))
                {
                    this.g_ClsSerialPortConfig.ReadWithoutCrypto(Common.CONFIG_FOLDER + Common.SERIALPORT_CONFIG_NAME);
                }
                this.g_ClsSerialPortControl = new ClsSerialPortControl(this.g_ClsSerialPortConfig, this.g_InfoManager);

                if (!this.g_ClsSerialPortControl.Open())
                {
                    ret++;
                }
            }
            catch (Exception ex)
            {

            }

            // connect adlink usb-1902
            try
            {

            }
            catch (Exception ex)
            {

            }

        }

        private void btnSendVoltage_Click(object sender, EventArgs e)
        {

        }

        private void btnDisConnect_Click(object sender, EventArgs e)
        {
            // disconnect gap sensor
            try
            {


            }
            catch (Exception ex)
            {

            }

            // disconnect adlink usb-1902
            try
            {

            }
            catch (Exception ex)
            {

            }

        }

        private void btnGetDistance_Click(object sender, EventArgs e)
        {

        }
    }
}
